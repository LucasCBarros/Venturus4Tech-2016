//
//  MainViewController.swift
//  HomeControl
//
//  Created by Rafael M. A. da Silva on 12/10/15.
//  Copyright © 2015 venturus. All rights reserved.
//

import UIKit

class MainViewController:UIViewController{
    
    
    @IBOutlet weak var temperatureImage: UIImageView!
    @IBOutlet weak var lampSwitch: UISwitch!
    @IBOutlet weak var temperatureLabel: UILabel!
    
    override func viewDidLoad() {
        
        lampSwitch.addTarget(self, action: #selector(MainViewController.switchLamp), forControlEvents: UIControlEvents.ValueChanged)
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(MainViewController.fetchTemperature))
        
        temperatureImage.userInteractionEnabled = true
        temperatureImage.addGestureRecognizer(tapGestureRecognizer)
        
        NSTimer.scheduledTimerWithTimeInterval(2, target: self, selector: #selector(MainViewController.fetchLampState) , userInfo: nil, repeats: true)
    }
    //////////////////////
    func fetchTemperature() {
        
        IOTService.sharedInstance.fetchTemperature(){(statuscode,error,homeModel)-> Void in
            self.temperatureLabel.text = "\(homeModel!.temperatureValue)º "
        }
//        print("fetchTemperature in progress... ")
    }
    /////////////////////////
    func switchLamp() {
        print("SwitchLamp Changed State ")
        let oldState = !lampSwitch.on
        IOTService.sharedInstance.switchLamp(lampSwitch.on){ (statusCode, error) -> () in
            if let _ = error {
                self.lampSwitch.setOn(oldState, animated: true)
            }
        }
    }
    //////////////////////////
    func fetchLampState() {
        IOTService.sharedInstance.fetchTemperature(){(statuscode,error)-> Void in
            self.lampSwitch.state = 
        }
        print("fetchLampState in progress... ")
//        print("get Lamp state")
    
    }
    
}
